﻿public static class Tags
{
    public const string Girl = "Girl";
    public const string Cat = "Cat";
    public const string Door = "Door";
    public const string Steppable = "Steppable";
    public const string Wall = "Wall";
    public const string Alter = "Alter";
    public const string Grid = "Grid";
}