public enum FaceDirection
{
    None,
    Left,
    Right,
    Up,
    Down
};