public interface IStepable
{
    void StepOn();
    void StepOff();
}