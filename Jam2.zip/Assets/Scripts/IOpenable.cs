﻿public interface IOpenable
{
    public void SetOpen(bool openStatus);

    public bool GetOpenStatus();

    public void SwapOpenState();
}